void mx_printchar(char c);
int mx_strcmp(const char *s1, const char *s2);
void mx_printstr(const char *s);

int main (int argc, char *argv[]) {
	char *buf;

	if (argc <= 1)
		return 0;
/*	if (argc == 2) {
		mx_printstr(argv[1]);
		mx_printchar('\n');
		return 0;
	}*/
	for(int i = 1; i < argc; i++) {
		for(int j = 1; j < argc - i; j++) {
			if (mx_strcmp(argv[j], argv[j + 1]) > 0) {
				buf = argv[j];
				argv[j] = argv[j + 1];
				argv[j + 1] = buf;
			}
		}
	}
	for(int i = 1; i < argc; i++) {
		mx_printstr(argv[i]);
		mx_printchar('\n');
	}
}

