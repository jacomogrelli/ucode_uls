char *mx_strcpy(char *dst, const char *src);
char *mx_strnew(const int size);
int mx_strlen(const char *s);

char *mx_strdup(const char *str) {
    const int size = mx_strlen(str);
    char *dup = mx_strnew(size);
    return mx_strcpy(dup, str);
}

#include <stdio.h>
int main () {
    const char *str;
    const char *dup;
    str = "result";
    dup = mx_strdup(str);
    printf("%s", dup);
}
