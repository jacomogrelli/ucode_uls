void mx_printchar(char c);

void mx_print_alphabet(void) {
	int i;

	for(i = 65; i < 91; i++) {
		mx_printchar(i);
		mx_printchar(i + 33);
		i = i + 1;
	}
	mx_printchar('\n');
}

