#include <stdlib.h>

char *mx_strnew(const int size) {
	char *str;
	
	str = (char *)malloc((size + 1) * sizeof(char));
	for (int i = 0; i <= size; i++) {
		str[i] = '1';
	}
	return str;
}

#include <stdio.h>
int main () {
	char *buf = mx_strnew(4);
    for(int i =0; i < 4; i++){
		printf("%c", buf[i]);
	}
}

