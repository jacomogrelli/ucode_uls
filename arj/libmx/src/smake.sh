clear
clang -std=c11 -Werror -Wextra -Wall -Wpedantic -c *.c
clang -std=c11 -Werror -Wextra -Wall -Wpedantic *.o -o 1 -fsanitize=address
rm *.o
