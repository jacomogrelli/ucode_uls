clear
clang -std=c11 -Werror -Wextra -Wall -Wpedantic -c *.c
clang -std=c11 -Werror -Wextra -Wall -Wpedantic *.o -g
rm *.o
