#include "libmx.h"

int main (/*int argc, char **argv*/) {
    // //mx_pop_front
    // t_list *res = NULL;
    //t_list *res = mx_create_node("123");
    // t_list *res = NULL;
    //mx_push_back(&res, "abc");
    //mx_push_back(&res, "deaf");
    // printf("%d\n", mx_list_size(res));

    //strnew
    // char *str = mx_strnew(-5);
    // printf("%s", str);

    // //mx_pop_back
    // t_list *res = mx_create_node("123");
    // mx_push_back(&res, "abc");
    // mx_push_back(&res, "deaf");
    // printf("before deleting\n");
    // t_list *head = res;
    // while(res != NULL) {
    //     mx_printstr(res->data);
    //     res = res->next;
    // }
    // res = head;
    // printf("\n");
    // mx_pop_back(&res);
    // printf("deleted\n");
    // while(res != NULL) {
    //     mx_printstr(res->data);
    //     res = res->next;
    // }

    // //mx_pop_front
    // t_list *res = mx_create_node("123");
    // mx_push_back(&res, "abc");
    // mx_push_back(&res, "deaf");
    // printf("before deleting\n");
    // t_list *head = res;
    // while(res != NULL) {
    //     mx_printstr(res->data);
    //     res = res->next;
    // }
    // res = head;
    // printf("\n");
    // mx_pop_front(&res);
    // printf("deleted\n");
    // while(res != NULL) {
    //     mx_printstr(res->data);
    //     res = res->next;
    // }

    //mx_push_front
    // t_list *res = mx_create_node("123");
    // t_list *res = NULL;
    // mx_push_front(&res, "0");
    // while(res != NULL) {
    //     mx_printstr(res->data);
    //     res = res->next;
    // }
   

    //mx_create_node
    //int temp = 13456;
    //char temp[] = "list_struct";
    // t_list *res;
    // res = mx_create_node((void *)temp);
    // printf("%d\n", res->data);
    
    //mx_realloc
    // char *p;
    // p = (char *) malloc(17);
    // strcpy(p, "This is 16 chars");
    // // p = (char *) realloc (p, 29);
    // p = (char *) mx_realloc (p, 29);
    // //strcat (p, ".");
    // printf("%s\n", p);
    // printf("%zu\n", malloc_size(p));
    // free(p);
    // return 0;

    //mx_memmove
 //    char one[] = "asdf is check of memmove";
 //    char pk[] = "1111";
 //    char pk2[] = "222";
	// char two[] = "shit";
 //    //char two1[] = "";
 //    memmove(two, one, 5);
 //    memmove(pk2, one, 4);
 //    printf("___________________________%s\n", pk);
 //    //mx_memmove(two1, one, 5);
 //    printf("%s\n", two);

 //    printf("___________________________%s\n", pk2);
    //printf("%s\n", two1);
    // char dst[] = "shif";
    // char dst1[] = "shif";
    // const char src[] = "mama myla ramu";
    // printf("%s\n", memmove(dst, src, 5));    
    // printf("%s\n", mx_memmove(dst1, src, 5));

    //mx_memmem
    // const char big[] = "big dog big big girl";
    //const char *big = NULL;
    //const char little[] = "dog";
    // const char *little = NULL;
    // printf("%s\n", memmem(big, 21, little, 3));
    // printf("%s\n", mx_memmem(big, 21, little, 3));

    
    //mx_memrchr
    // const char src[] = "Trinity";
    // printf("%s\n", mx_memrchr(src, 'T', 0));
    // printf("%s\n", src);
        
    //mx_memchr
    // const char src[] = "0123456789";
    // printf("%s\n", mx_memchr(src, 'p', 8));
    // printf("%s\n", src);
    // printf("%s\n", memchr(src, 'p', 8));

    //mx_memcmp
    // const char s1[] = "123456789";
    // const char s2[] = "123456789";
    // printf("%d\n", mx_memcmp(s1, s2, 9));
    // printf("%d\n", memcmp(s1, s2, 9));

    //mx_file_to_str
    // char *res = NULL;
    // if (argc > 0)
    // res = mx_file_to_str(argv[1]);
    // printf("%s", res);

    //mx_memccpy
    // char src[] = "0123456789";
    // char dst1[] = "abcdefigkl";
    // char dst2[] = "abcdefigkl";
    // printf("mx - %s\n", mx_memccpy(dst1, src, 'a', 11));
    // printf("lib - %s\n", memccpy(dst2, src, 'a', 11));
    // printf("%s\n", dst1);
    // printf("%s\n", dst2);

    //mx_memcpy
    // char src[] = "0123456789";
    // char dst[] = "4TuCLSYzkdyNYUKqQSHCfxvGOAZ9SI0IK3y8rqyd3jUGT82eM4QsB";
    // char dst2[] = "4TuCLSYzkdyNYUKqQSHCfxvGOAZ9SI0IK3y8rqyd3jUGT82eM4QsB";
    // printf("mx  - %s\n", mx_memcpy(dst, src, 50));
    // printf("lib - %s\n", memcpy(dst2, src, 50));
    // printf("after mx  - %s\n", dst);
    // printf("after lib - %s\n", dst2);
    
    //mx_memset
    // char arr1[] = "234567890";
    // memset(arr1, '1', 5);
    // char arr[] = "234567890";
    // mx_memset(arr, '1', 5);
    // char *arr1[] = {"234567890", "234567890", "234567890", "234567890", "234567890"};
    // memset(arr1, '1', 2);
    // for (int i = 0; i < 5; i++) printf("%s\n", arr1[i]);
    // char *arr[] = {"234567890", "234567890", "234567890", "234567890", "234567890"};
    // mx_memset(arr, '1', 2);
    // for (int i = 0; i < 5; i++) printf("%s\n", arr[i]);
    // // printf("%s\n", arr);
    // // printf("%s\n", arr1);
    
    //mx_itoa
    //printf("%s", mx_itoa(-2147483648));
    //printf("%s", mx_itoa(0));
    //printf("%s", mx_itoa(2147483647));
    
    //mx_nbr_to_hex
    // char *str = mx_nbr_to_hex(1000);
    // printf("%s\n", str);
    // free(str);

    //mx_quick_sort
    // char *arr[] = {"666666", "333", "999999999", "1", "88888888", "4444", "55555", "7777777", "22"};
    // //char *arr[] = {"Michelangelo", "Donatello", "Leonardo", "Raphael"};
    // printf("%d\n", mx_quicksort(arr, 0, 8));
    // for (int i = 0; i < 9; i++)
    //     printf("%s\n", arr[i]);
    //mx_replace_substr
    // char *test = NULL;
    // test = ;
    //printf("%s\n", mx_replace_substr("McDonalds", "alds", "uts"));
    // printf("%s\n", mx_replace_substr("Ururu turu", "ru", "ta"));

    //mx_strsplit
    // const char str[] = " **Good bye,**Mr.*Anderson.****";
    //const char *str = NULL;
    // const char str[] = "   asdf            ";
    // // const char str[] = "Knock, knock,    Neo.   ";
    // char **res = NULL;
    // res = mx_strsplit(str, ' ');
    // for (int i = 0; res[i] != NULL; i++) {
    //     printf("%s\n", res[i]);
    // }

    //mx_del_extra_spaces
    // const char str[] = "\f  My name...    \r is  Neo  \t\n ";
    // const char str[] = "         ";
    // printf("%s", str);
    // printf("mx_strtrim main %s\n", mx_strtrim(str));
    // printf("%s\n", mx_del_extra_spaces(str));

    

    //mx_strtrim
    // const char name[] = "\f  My name... is Neo  \n ";
    // const char name[] = "             ";
    // const char name[] = "  My name...    is   Neo  \t\n ";
    // printf("%s", mx_strtrim(name));
    

    
    //mx_count_words
    // const char str[] = "";
    // // const char str[] = "  follow  *   the  white rabbit";
    // printf("%d\n", mx_count_words(str, ' '));
    
    //mx_count_substr
    // const char str[] = "yo, yo, yo Neo";
    // const char sub[] = "yo";
    // const char str[] = "mamamamama";
    // const char sub[] = "m";
    // const char *str = NULL;
    // const char *sub = NULL;
    // printf("%d\n", mx_count_substr(str, sub));

    //mx_get_substr_index
    // const char haystack[] = "this is halloween halloween";
    // const char needle[] = "eennnn";
    // printf("%d\n", mx_get_substr_index(haystack, needle));
    // printf("%s\n", haystack);

    //mx_strstr
    // const char *haystack = NULL;
    // const char haystack[] = "this is halloween halloween";
    // const char *needle = "eenn";
    // printf("%s\n", mx_strstr(haystack, needle));
    // printf("%s\n", strstr(haystack, needle));
    // printf("%s\n", haystack);
    // //if (mx_strstr(haystack, needle) == NULL)
    // //    printf("rabotaet");

    //mx_strcat
    // char s1[] = "number";
    // const char s2[] = " enter";
    // // printf("%s\n", strcat(s1, s2));
    // printf("%s\n", mx_strcat(s1, s2));

    //mx_strndup
    /*const char str[] = "source";
    printf("%s\n", mx_strndup(str, -4));*/
    
    //mx_print_strarr
    // char *arr[] = {"123", "456", "789", "0", NULL};
    // char delim[] = {"abc"};
    // mx_print_strarr(arr, delim);

    //mx_hex_to_nbr
    /*//printf("%lu", mx_hex_to_nbr("ffffffffffff"));
    printf("%lu", mx_hex_to_nbr(NULL));*/

    //mx_strjoin
    // const char str1[] = "123";
    // const char str2[] = "456";
    // char *str;
    // printf("%s\n", str = mx_strjoin(str1, str2));

    //mx_swap_char
    /*char str[] = "ONE";
    mx_swap_char(&str[1], &str[2]);
    printf("%s\n", str);*/
    
    //mx_str_reverse
    /*char s[] = "game over";
    mx_str_reverse(s);
    printf("%s\n", s);*/

    //mx_strdel
    /*char *str = malloc(10);
    str = NULL;
    mx_strdel(&str);
    //if (str == NULL)
    //    printf("taki NULL");*/

    //mx_strdup
    // const char str[] = "123456";
    // char *res;
    // printf("%s\n", res = mx_strdup(str));
    // mx_printstr(res);


    //mx_del_strarr
    // char **arr;
    // arr = (char**)malloc(sizeof(char*) * 5);
    // free(arr);
    // for (int i = 0; i < 5; i++) {
    //     arr[i] = (char*)malloc(1);
    // }
    // arr[4] = NULL;
    // free(arr);
    // mx_del_strarr(&arr);
    //     if (arr[0] == NULL)
    //     printf("arr NULL");

    //mx_get_char_index
    /*const char *str = NULL;
    printf("%d\n", mx_get_char_index(str, 'z'));*/

    //mx_strncpy
    // const char *src = NULL;
    // const char src[] = "Qp3qFdj2dx";
    // char dst1[] = "11111111CGPXfMhvK4";
    // char dst2[] = "11111111CGPXfMhvK4";
    // //printf("%s\n", dst);
    // printf("lib - %s\n", strncpy(dst1, src, 5));
    // printf("mx  - %s\n", mx_strncpy(dst2, src, 5));

    //  system("\nleaks a.out");
    // return 0;
}

