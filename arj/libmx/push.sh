#!/bin/bash
grep 'printf' ./src/*.c
echo "PRESS ANY KEY to continue or CTRL + C if PRINTF"
read var
git add .
git status
echo "PRESS ANY KEY to continue or CTRL + C to abort pushing"
read var
git commit -m "_"
git push
git status
