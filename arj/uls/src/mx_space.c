#include "uls.h"

void mx_space(int count) {
    for (int i = 0; i < count; i++) {
        mx_printchar(' ');
    }
}
