#ucodeworld
#unit.factory
#uls

Developed by ucode students:
Oleksiy Nechaiev (onechaiev, nechaeff@gmail.com)
Andriy Ilchuk (ailchuk, an_ilchuk27@gmail.com)

Our implementation of the Unix command: ls, using the C programming language.

[Introduction] [1]

Developed with:
MacOS X Mojave 10.14.5 (other OS not tested)
clang
GNU make

how to use:
0. clone repo
1. make
2. usage: uls [-AFGRSldmortu1] [file ...]
